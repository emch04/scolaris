require("dotenv").config();
const gemini = require("./src/utils/gemini.service");

async function test() {
  console.log("📡 Test de connexion Gemini en cours...");
  try {
    const response = await gemini.ask("Bonjour, es-tu opérationnel ?");
    console.log("🤖 Réponse de Gemini :", response);
  } catch (err) {
    console.error("❌ Erreur de test :", err.message);
  }
}

test();
