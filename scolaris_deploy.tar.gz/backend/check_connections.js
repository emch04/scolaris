require("dotenv").config();
const mongoose = require("mongoose");

const testConnections = async () => {
  console.log("🔍 Test des connexions Scolaris...");
  
  try {
    // 1. Test Base Principale
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("✅ Base Principale : CONNECTÉE");

    // 2. Test Base de Logs
    const logsURI = process.env.MONGODB_LOGS_URI;
    if (!logsURI) {
      console.log("⚠️  Base de Logs : Variable MONGODB_LOGS_URI manquante. Utilisation du fallback (Base Principale).");
    } else {
      const logConn = mongoose.createConnection(logsURI);
      logConn.on('connected', () => {
        console.log("✅ Base de Logs : CONNECTÉE (Cluster séparé)");
        process.exit(0);
      });
      logConn.on('error', (err) => {
        console.log("❌ Base de Logs : ERREUR - " + err.message);
        process.exit(1);
      });
    }
    
    // Si on arrive ici sans URI spécifique, on attend un peu et on coupe
    setTimeout(() => {
        if (!logsURI) process.exit(0);
    }, 2000);

  } catch (error) {
    console.error("❌ Erreur Critique : " + error.message);
    process.exit(1);
  }
};

testConnections();
