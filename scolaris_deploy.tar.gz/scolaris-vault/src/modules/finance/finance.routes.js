const express = require('express');
const router = express.Router();
const { createFee, getFees, recordPayment, getPayments, paySalary, getTreasuryStats } = require('./finance.controller');
const { parseProxyUser, authorizeRoles } = require('../../middlewares/proxyAuth');
const ROLES = require('../../constants/roles');

// Tout trafic vers la Finance doit passer par le décodeur d'identité du Proxy (Backend)
router.use(parseProxyUser);

const FINANCE_STAFF = [ROLES.HERO_ADMIN, ROLES.DIRECTOR, ROLES.ADMIN, ROLES.SECRETARY];

router.get('/treasury', authorizeRoles(...FINANCE_STAFF), getTreasuryStats);
router.get('/payments', authorizeRoles(...FINANCE_STAFF), getPayments);
router.get('/fees-list', authorizeRoles(...FINANCE_STAFF), getFees);

router.post('/fees', authorizeRoles(ROLES.HERO_ADMIN, ROLES.DIRECTOR, ROLES.ADMIN), createFee);
router.post('/payments', authorizeRoles(ROLES.HERO_ADMIN, ROLES.ADMIN, ROLES.SECRETARY), recordPayment);
router.post('/salaries', authorizeRoles(ROLES.HERO_ADMIN, ROLES.DIRECTOR, ROLES.ADMIN), paySalary);

module.exports = router;
