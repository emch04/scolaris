require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const compression = require("compression");

const app = express();

// 1. SÉCURITÉ MAXIMUM (Le Vault est caché)
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_SERVERS ? process.env.ALLOWED_SERVERS.split(",") : "*",
  credentials: true
}));

app.use(compression());
app.use(express.json({ limit: "20mb" })); // Plus large pour les PDF et rapports

// 2. MIDDLEWARE DE CONFIANCE (The Vault Shield)
app.use((req, res, next) => {
  const vaultKey = req.headers["x-vault-key"];
  if (vaultKey !== process.env.VAULT_INTERNAL_KEY) {
    return res.status(403).json({ success: false, message: "Accès refusé au Coffre-Fort." });
  }
  next();
});

// 3. ROUTES
app.get("/status", (req, res) => {
  res.json({ success: true, module: "Vault", status: "Armored" });
});

app.use("/api/finance", require("./src/modules/finance/finance.routes"));

// Gestion d'erreurs
app.use((err, req, res, next) => {
  console.error("Vault Error:", err.message);
  res.status(500).json({ success: false, message: "Erreur interne au Vault." });
});

module.exports = app;
