const { GoogleGenerativeAI } = require("@google/generative-ai");
const anonymizer = require("./anonymizer.service");
const toolHandler = require("./toolHandler.service");

/**
 * Définition des outils (Function Calling) pour Gemini
 */
const scolarisTools = [
  {
    functionDeclarations: [
      {
        name: "get_student_details",
        description: "Récupère les informations détaillées d'un élève (matricule, école, parent) à partir de son nom ou de son matricule.",
        parameters: {
          type: "OBJECT",
          properties: {
            identifier: {
              type: "STRING",
              description: "Le nom complet ou le matricule de l'élève."
            }
          },
          required: ["identifier"]
        }
      },
      {
        name: "get_school_stats",
        description: "Obtient les statistiques vitales d'un établissement (nombre d'élèves, enseignants) par son nom.",
        parameters: {
          type: "OBJECT",
          properties: {
            schoolName: {
              type: "STRING",
              description: "Le nom de l'école."
            }
          },
          required: ["schoolName"]
        }
      },
      {
        name: "search_knowledge_base",
        description: "Recherche des informations dans les règlements officiels, les lois scolaires et les programmes. Priorise la base locale pour la RDC, sinon utilise tes connaissances mondiales pour les autres pays.",
        parameters: {
          type: "OBJECT",
          properties: {
            query: {
              type: "STRING",
              description: "La question ou les mots-clés de recherche (ex: exclusion, frais scolaire, calendrier)."
            }
          },
          required: ["query"]
        }
      },
      {
        name: "get_network_strategic_analysis",
        description: "Fournit une analyse profonde et globale du réseau Scolaris : parité de genre, distribution géographique des écoles et taux de réussite national.",
        parameters: {
          type: "OBJECT",
          properties: {}
        }
      },
      {
        name: "get_class_performance",
        description: "Analyse la performance académique d'une classe spécifique.",
        parameters: {
          type: "OBJECT",
          properties: {
            className: {
              type: "STRING",
              description: "Le nom de la classe (ex: 6ème A)."
            }
          },
          required: ["className"]
        }
      }
    ]
  }
];

/**
 * Service Scolaris Gemini v2 - "Cognitive Oracle"
 */
class GeminiService {
  constructor() {
    this.apiKey = process.env.GEMINI_API_KEY;
    if (this.apiKey) {
      this.genAI = new GoogleGenerativeAI(this.apiKey);
      
      // Configuration avec outils pour le modèle PRO
      this.modelPro = this.genAI.getGenerativeModel({ 
        model: "gemini-1.5-pro",
        tools: scolarisTools 
      });
      
      this.modelFlash = this.genAI.getGenerativeModel({ 
        model: "gemini-1.5-flash",
        tools: scolarisTools 
      });

      // Modèle d'embedding pour la mémoire sémantique
      this.embeddingModel = this.genAI.getGenerativeModel({ model: "text-embedding-004" });
    }
  }

  /**
   * Génère un vecteur (embedding) pour un texte donné
   */
  async getEmbedding(text) {
    if (!this.apiKey || !text) return null;
    try {
      const result = await this.embeddingModel.embedContent(text);
      return result.embedding.values;
    } catch (error) {
      console.error("Embedding Error:", error.message);
      return null;
    }
  }

  /**
   * Gère l'exécution des appels de fonctions demandés par Gemini
   */
  async handleFunctionCalls(functionCalls) {
    const results = {};
    for (const call of functionCalls) {
      const { name, args } = call;
      console.log(`[IA ACTION] Exécution de : ${name}`, args);
      
      if (typeof toolHandler[name] === 'function') {
        results[name] = await toolHandler[name](args);
      } else {
        results[name] = { error: "Outil non implémenté." };
      }
    }
    return results;
  }

  /**
   * Pose une question à Gemini en injectant le contexte de la plateforme
   * Supporte maintenant les images (Vision) et l'Auto-Optimisation
   */
  async ask(prompt, sensitiveEntities = [], systemContext = null, imageData = null) {
    if (!this.apiKey) return "Désolé, l'API Gemini n'est pas configurée.";

    try {
      const isOverloaded = systemContext && (systemContext.health.ram > 80 || systemContext.health.cpu > 0.8);
      const safePrompt = anonymizer.mask(prompt, sensitiveEntities);

      let contextString = "";
      if (systemContext) {
        contextString = `
        CONTEXTE ACTUEL DU SYSTÈME SCOLARIS :
        - Plateforme : ${systemContext.platform}
        - Date et heure : ${systemContext.date}
        - Effectif total : ${systemContext.totalStudents} élèves
        - Ratio Filles/Total : ${systemContext.parity}%
        - Nombre d'établissements : ${systemContext.totalSchools}
        - Taux de réussite global : ${systemContext.avgRate}%
        - Santé serveur : RAM ${systemContext.health.ram}%, CPU ${systemContext.health.cpu}
        - MODE : ${isOverloaded ? 'ÉCONOMIE D\'ÉNERGIE (CPU CRITIQUE)' : 'PERFORMANCE MAXIMALE'}
        `;
      }

      const economyInstruction = isOverloaded 
        ? "ATTENTION : Le serveur est surchargé. Sois extrêmement bref (1 phrase), désactive toute analyse non essentielle et n'utilise pas d'outils si possible."
        : "Sois visionnaire, universel et stratégique. Utilise les outils à ta disposition.";

      const systemInstruction = `Tu es Scolaris IA, le cerveau stratégique de la plateforme Scolaris.
      Tu es l'allié d'Emch.
      ${contextString}
      
      CONSIGNES :
      - ${economyInstruction}
      - Si une image est fournie, analyse-la avec précision.
      - Si on te pose une question sur la législation scolaire, cherche d'abord dans la base de connaissances locale (RDC).
      - Réponds toujours de manière concise.`;

      // Sélection du modèle en fonction de la charge
      const selectedModel = isOverloaded ? this.modelFlash : this.modelPro;
      const chat = selectedModel.startChat();
      
      // Préparation du contenu du message
      const messageParts = [`${systemInstruction}\n\nQuestion de l'utilisateur : ${safePrompt}`];
      
      if (imageData) {
        messageParts.push(imageData);
      }

      // Envoi du message
      let result = await chat.sendMessage(messageParts);
      let response = await result.response;
      
      // Gestion des outils (désactivée en mode surcharge pour économiser le CPU)
      let functionCalls = response.functionCalls();
      
      if (functionCalls && !isOverloaded) {
        const toolResults = await this.handleFunctionCalls(functionCalls);
        
        const responseParts = Object.keys(toolResults).map(name => ({
          functionResponse: {
            name,
            response: { content: toolResults[name] }
          }
        }));
        
        result = await chat.sendMessage(responseParts);
        response = await result.response;
      }

      let finalResponse = response.text();
      if (isOverloaded) finalResponse = `[MODE ÉCONOMIE ACTIVE] ${finalResponse}`;

      return anonymizer.unmask(finalResponse);

    } catch (error) {
      console.error("Gemini Cognitive Error:", error.message);
      
      let errorMessage = "Mon module de réflexion supérieure est saturé. Je reste disponible pour les analyses locales.";
      
      if (error.message.includes("API_KEY_INVALID")) {
        errorMessage = "⚠️ Erreur : Votre clé API Gemini est invalide ou non configurée.";
      } else if (error.message.includes("quota") || error.message.includes("429")) {
        errorMessage = "⚠️ Limite de débit atteinte (Quota). Veuillez réessayer dans une minute.";
      } else if (error.message.includes("model") && error.message.includes("not found")) {
        errorMessage = "⚠️ Erreur : Le modèle Gemini 1.5 n'est pas disponible dans votre région ou pour cette clé.";
      } else {
        // En dernier recours, on essaie le modèle FLASH sans outils (plus robuste)
        try {
          console.log("Tentative de secours ultime avec Flash (sans outils)...");
          const modelBasic = this.genAI.getGenerativeModel({ model: "gemini-1.5-flash" });
          const result = await modelBasic.generateContent(prompt);
          return anonymizer.unmask((await result.response).text());
        } catch (fError) {
          console.error("Échec du secours ultime:", fError.message);
        }
      }

      return errorMessage;
    }
  }
}

module.exports = new GeminiService();
