/**
 * @file predictive.monitor.js
 * @description Analyse prédictive 24/7 du système Backend.
 */

const os = require('os');
const mongoose = require('mongoose');

let isMonitoring = false;
let lastCriticalAlert = null; // Mémoire de l'alerte active

const startPredictiveMonitoring = () => {
  if (isMonitoring) return;
  isMonitoring = true;
  console.log("🤖 IA Prédictive IA-Service activée.");

  setInterval(async () => {
    try {
      const issues = [];
      let level = 'WARN';

      // 1. Analyse RAM du conteneur IA
      const totalMem = os.totalmem();
      const freeMem = os.freemem();
      const usedMemPercentage = ((totalMem - freeMem) / totalMem) * 100;
      if (usedMemPercentage > 95) issues.push(`Surcharge RAM IA (${usedMemPercentage.toFixed(1)}%)`);

      // 2. Base de données
      const dbState = mongoose.connection.readyState;
      if (dbState !== 1) {
        issues.push("Base de données déconnectée de l'IA");
        level = 'FATAL';
      }

      // Gestion de l'alerte
      if (issues.length > 0) {
        const message = "🚨 ALERTE IA-SERVICE : " + issues.join(" | ");
        lastCriticalAlert = { message, level, time: new Date() };
        console.warn(`[${level}] ${message}`);
      } else {
        lastCriticalAlert = null;
      }

    } catch (err) { console.error("IA Monitor Error:", err.message); }
  }, 60000); // Toutes les minutes pour le service IA
};

module.exports = { 
  startPredictiveMonitoring,
  getLastAlert: () => {
    // L'alerte est valide si elle a moins de 2 minutes
    if (lastCriticalAlert && (Date.now() - lastCriticalAlert.time < 120000)) {
        return lastCriticalAlert;
    }
    return null;
  }
};
