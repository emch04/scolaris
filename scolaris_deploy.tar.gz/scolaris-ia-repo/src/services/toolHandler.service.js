const Student = require('../models/student.model');
const School = require('../models/school.model');
const Result = require('../models/result.model');
const Teacher = require('../models/teacher.model');
const Classroom = require('../models/classroom.model'); // Je dois vérifier s'il existe dans l'IA
const mongoose = require('mongoose');
const knowledgeService = require('./knowledge.service');

/**
 * Service de gestion des outils (Function Calling) pour Scolaris IA
 */
class ToolHandler {

  async search_knowledge_base({ query }) {
    return await knowledgeService.search(query);
  }
  
  async get_student_details({ identifier }) {
    try {
      const student = await Student.findOne({
        $or: [
          { matricule: identifier },
          { fullName: { $regex: identifier, $options: 'i' } }
        ]
      }).populate('school').lean();

      if (!student) return { error: "Élève non trouvé." };

      return {
        fullName: student.fullName,
        matricule: student.matricule,
        school: student.school?.name || "Non assigné",
        gender: student.gender,
        parentName: student.parentName,
        status: "Inscrit"
      };
    } catch (error) {
      return { error: error.message };
    }
  }

  async get_class_performance({ className }) {
    try {
      // Pour cet outil, on va simuler ou chercher via les résultats
      const results = await Result.find({}).lean();
      // Logique simplifiée pour l'exemple
      return {
        className,
        average: "14.5/20",
        topStudent: "Jean Bakoko",
        status: "Performance Satisfaisante"
      };
    } catch (error) {
      return { error: error.message };
    }
  }

  async get_school_stats({ schoolName }) {
    try {
      const school = await School.findOne({ name: { $regex: schoolName, $options: 'i' } });
      if (!school) return { error: "École non trouvée." };

      const studentCount = await Student.countDocuments({ school: school._id });
      const teacherCount = await Teacher.countDocuments({ school: school._id });
      const stats = await Result.aggregate([
        { $match: { student: { $in: await Student.find({ school: school._id }).distinct('_id') } } },
        { $group: { _id: null, avg: { $avg: { $divide: ["$score", "$maxScore"] } } } }
      ]);

      return {
        schoolName: school.name,
        totalStudents: studentCount,
        totalTeachers: teacherCount,
        ratio: teacherCount > 0 ? (studentCount / teacherCount).toFixed(1) : "N/A",
        successRate: stats.length ? (stats[0].avg * 100).toFixed(1) + "%" : "N/A",
        location: school.commune || "International"
      };
    } catch (error) {
      return { error: error.message };
    }
  }

  /**
   * Analyse stratégique profonde du réseau Scolaris
   */
  async get_network_strategic_analysis() {
    try {
      const totalStudents = await Student.countDocuments();
      const totalSchools = await School.countDocuments();
      
      // 1. Parité de genre
      const genderStats = await Student.aggregate([
        { $group: { _id: "$gender", count: { $sum: 1 } } }
      ]);

      // 2. Distribution géographique (Villes/Régions)
      const geoStats = await School.aggregate([
        { $group: { _id: "$commune", schoolCount: { $sum: 1 } } },
        { $sort: { schoolCount: -1 } },
        { $limit: 5 }
      ]);

      // 3. Performance globale
      const globalPerformance = await Result.aggregate([
        { $group: { _id: null, avg: { $avg: { $divide: ["$score", "$maxScore"] } } } }
      ]);

      return {
        overview: { totalStudents, totalSchools },
        genderParity: genderStats.reduce((acc, curr) => {
          acc[curr._id || "Inconnu"] = curr.count;
          return acc;
        }, {}),
        topRegions: geoStats.map(c => `${c._id || 'Inconnue'}: ${c.schoolCount} écoles`),
        globalSuccessRate: globalPerformance.length ? (globalPerformance[0].avg * 100).toFixed(1) + "%" : "0%"
      };
    } catch (error) {
      return { error: error.message };
    }
  }
}

module.exports = new ToolHandler();
