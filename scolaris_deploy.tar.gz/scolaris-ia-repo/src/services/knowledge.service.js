const fs = require('fs');
const path = require('path');

/**
 * Service de Recherche Documentaire (RAG Light)
 * Permet de chercher des informations dans la base de connaissances locale.
 */
class KnowledgeService {
  constructor() {
    this.knowledgePath = path.join(__dirname, '../../knowledge/rdc_regulations.json');
  }

  /**
   * Recherche par mots-clés dans la base de connaissances
   */
  async search(query) {
    try {
      if (!fs.existsSync(this.knowledgePath)) return { error: "Base de connaissances introuvable." };
      
      const data = JSON.parse(fs.readFileSync(this.knowledgePath, 'utf8'));
      const searchTerms = query.toLowerCase().split(' ');
      
      // Recherche simple par pertinence (nombre de mots-clés correspondants)
      const results = data.map(doc => {
        let score = 0;
        searchTerms.forEach(term => {
          if (doc.topic.toLowerCase().includes(term)) score += 5;
          if (doc.content.toLowerCase().includes(term)) score += 2;
          if (doc.keywords.some(k => k.toLowerCase().includes(term))) score += 3;
        });
        return { ...doc, score };
      })
      .filter(doc => doc.score > 0)
      .sort((a, b) => b.score - a.score);

      if (results.length === 0) return { message: "Aucun document officiel trouvé pour cette recherche." };

      // On retourne le meilleur résultat
      return {
        topic: results[0].topic,
        content: results[0].content,
        source: "Documentation Officielle (Local/International)"
      };
    } catch (error) {
      return { error: error.message };
    }
  }
}

module.exports = new KnowledgeService();
