require("dotenv").config();
const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
const morgan = require("morgan");
const mongoose = require("mongoose");

const app = express();

// Middlewares
app.use(helmet());
app.use(cors());
app.use(express.json());
app.use(morgan("dev"));

// Connexion MongoDB (IA gère les deux bases : Core et Logs)
const connectDB = require("./src/config/db");
connectDB().then(() => {
  console.log("🧠 Scolaris IA : Systèmes de données connectés");
});

// Import des Services
const blackBox = require("./src/services/blackbox.service");

// Routes
app.get("/status", (req, res) => {
  res.json({ success: true, status: "online", module: "scolaris-ia" });
});

/**
 * Route principale pour le traitement IA
 */
app.post("/api/ia/command", async (req, res) => {
  try {
    const { command, context, imageData } = req.body;
    const response = await blackBox.processCommand(command, imageData);
    res.json({ success: true, data: response });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Route pour récupérer l'historique des chats
 */
app.get("/api/ia/history", async (req, res) => {
  try {
    const history = await blackBox.getChatHistory();
    res.json({ success: true, data: history });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

/**
 * Health Check & Monitoring System
 */
app.get("/api/ia/health", (req, res) => {
  const health = blackBox.getSystemHealth();
  res.json({ success: true, data: health });
});

const PORT = process.env.PORT || 5002;
app.listen(PORT, () => {
  console.log(`🧠 Moteur Scolaris IA lancé sur le port ${PORT}`);
});
