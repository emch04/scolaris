# 🧠 Scolaris IA - Moteur Cognitif

Ce dépôt contient le moteur d'Intelligence Artificielle de Scolaris, extrait du projet principal pour optimiser les performances et la consommation de RAM.

## 🚀 Déploiement sur Render

1.  **Créer un nouveau Web Service** sur Render.
2.  Connecter ce dépôt GitHub (`emch04/scolaris-ia`).
3.  **Configuration du Build** :
    *   Runtime : `Node`
    *   Build Command : `npm install`
    *   Start Command : `npm start`
4.  **Variables d'Environnement** :
    *   `PORT` : `5002` (ou celui de votre choix)
    *   `MONGODB_URI` : L'URL de votre base de données principale.
    *   `MONGODB_LOGS_URI` : L'URL de votre base de données de logs.
    *   `GEMINI_API_KEY` : Votre clé API Google Gemini.
    *   `NODE_ENV` : `production`

## 🔗 Liaison avec le Backend Principal

Dans le backend de votre application principale, assurez-vous d'ajouter cette variable dans votre `.env` :
`IA_SERVICE_URL=https://votre-service-ia.onrender.com`

## 🛠️ Architecture
- **BlackBox** : Traitement des commandes stratégiques.
- **Oracle** : Intégration avec Gemini 2.5 Flash.
- **Shield** : Anonymisation des données sensibles avant envoi.
- **Predictive** : Surveillance de la santé du système (DB & Statut).
